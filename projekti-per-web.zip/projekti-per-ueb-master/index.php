<?php
include_once 'models\DbConn.php';
include 'Controler\productControler.php';
include 'views/header.php';
?>


  <div class="main">
    <div class="mainright">
      <h1>Addoring <br> your feelings.</h1>
      <p><span>80.90$</span> 50.90$</p>
      <button>Shop Now</button>
    </div>
    <div class="mainleft">
      <img src="images/arusha-img.svg" alt="arusha">
    </div>
  </div>
  </div>

  <div class="getc">
    <div class="getconnected">
      <img src="images/girl-with-bear.png" alt="">
      <div class="gcontext">
        <h3><i>GET 35% OFF</i></h3>
        <h1>VALENTINE'S DAY</h1>
        <br>
        <p>You can shop online <br> Buy bear toy, to make someone happy like bear...</p>
        <button>Shop Now</button>
      </div>
    </div>
  </div>

  <div class="slideri">
    <div class="slider">
      <div class="slides">
        <div id="slide-1">
          <div class="permbajtasliderit">
            <img src="images/product.png" alt="">
            <h1>Worldwide Shipping</h1>
            <p>We ship the products worldwide from the heart of Kosovo. In just 2 days love Bear willbe at your door! We handle your products with the desired attention, to satisfy your experience. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Expedita placeat consequuntur ipsa rerum officia doloremque eum libero natus quos nihil, quisquam autem aperiam.</p>
          </div>
        </div>
        <div id="slide-2">
          <div class="permbajtasliderit">
            <img src="images/pay.png" alt="">
            <h1>Secure Payments</h1>
            <p>We offer secure payment service, with PayPal, or any major Credit Card company. All of your information will be encrypted and secure. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Expedita placeat consequuntur ipsa rerum officia doloremque eum libero natus quos nihil.</p>
          </div>
        </div>
        <div id="slide-3">
          <div class="permbajtasliderit">
            <img src="images/return.png" alt="">
            <h1>Safe Packaging</h1>
            <p>In the box you will get the bear of the desired size and color, with a special card note where you can share your thoughts for your special one. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Expedita placeat consequuntur ipsa rerum officia doloremque eum libero natus quos nihil, quisquam autem aperiam porro et quasi nesciunt?</p>
          </div>
        </div>
      </div>
      <a href="#slide-1"> </a>
      <a href="#slide-2"> </a>
      <a href="#slide-3"> </a>
    </div>
  </div>


  <div class="produktet">
    <div class="title0">
      <h1>ROSE BEAR</h1>
      <p><i>Quality is our first Priority</i></p>
    </div>
    <div class="cards">
      <?php

      $productC = new ProductControler();
      $result = $productC->GetProducts();

      if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
      ?>
          <div class="card">
            <img src="images/bear.jpeg" alt="" style="width:100%">
            <h1 style="font-size: 20px;"><?= $row['ProductName'] ?></h1>
            <p class="price"><i>$<?= $row["ProductPrice"] ?>.99</i></p>
            <button>Buy now</button>
          </div>

      <?php
        }
      } else {
        echo "0 results";
      }
      ?>
    </div>
  </div>

  <div class="content-1">
    <div class="leftcolumn">
      <div class="leftcolumn-inside">
        <p class="p1">ABOUT</p>
        <h1 class="h1-1">Where the <br> expectation is <br> more than money</h1>
        <a href="#" class="myButton">Learn More &rarr;</a>
      </div>
    </div>

    <div class="rightcolumn">
      <div class="rightcolumn-inside">
        <div class="content-wrapper1">
          <h1>Kosovos hand made</h1>
          <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptas, aliquam sed?
            Qui voluptatem harum nesciunt debitis quis velit laborum eligendi rem.
          </p>

          <a href="#" class="myButton">Get Started &rarr;</a>
        </div>
        <div class="img-2">
          <img src="images/rosebear.png" alt="rosebear">
        </div>
      </div>
    </div>
  </div>

  <footer>
    <div class="footercol1">
      <p>Your satisfaction is always our first priority!</p>
      <p>All rights reserved 2020</p>
    </div>
    <div class="footercol2">
      <p>Follow us</p>
      <div>
        <a href="https://instagram.com">
          <img src="images/instagram.png" alt="">
        </a>
        <a href="https://twitter.com">
          <img src="images/twitter.png" alt="">
        </a>
        <a href="https://facebook.com">
          <img src="images/facebook.png" alt="">
        </a>
      </div>
    </div>
    <div class="footercol3">
      <p>We accept payments in:</p>
      <img src="images/paymentoptions.png" alt="">
    </div>
  </footer>

  <script src="main.js"></script>
</body>

</html>