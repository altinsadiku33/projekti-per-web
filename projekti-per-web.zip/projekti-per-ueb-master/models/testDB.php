<?php
include 'DbConn.php';
?>
<html>
    <body>
        <?php
            $testlidhja = new DbConn();
            $testlidhja-> connectDB();
        ?>
    </body>
</html>