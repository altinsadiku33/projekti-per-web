<?php
class ContactModel
{
    private $name;
    private $email;
    private $message;
    private $phone;

    /**
     * ContactModel constructor.
     * @param $name
     * @param $email
     * @param $phone
     * @param $message
     */
    public function __construct($name, $email, $phone, $message)
    {
        $this->name = $name;
        $this->email = $email;
        $this->message = $message;
        $this->phone = $phone;
    }

    public function getName()
    {
        return $this->name;
    }
    public function getEmail()
    {
        return $this->email;
    }
    public function getPhone()
    {
        return $this->phone;
    }

    public function getMessage()
    {
        return $this->message;
    }
}
