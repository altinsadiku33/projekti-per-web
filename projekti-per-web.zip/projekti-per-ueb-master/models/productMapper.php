<?php
include_once 'DbConn.php';
include_once 'productModel.php';
class productMapper
{
    private $product;
    private $connection;
    public function __construct(\Product $product)
    {
        $obj = new DBConn();
        $this->connection = $obj->connectDB();
        $this->product = $product;
    }

    public function Insert()
    {
        $stmt = $this->connection->prepare("INSERT INTO product (ProductName,ProductDescription, ProductPrice, ProductColor, ProductImagePath) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdss", $name, $description, $price, $color, $image);

        $name = $this->product->getProductName();
        $description = $this->product->getProductDescription();
        $price = $this->product->getProductPrice();
        $color = $this->product->getProductColor();
        $image = $this->product->getProductImagePath();
        $stmt->execute();


        // $sql = "INSERT INTO product (ProductName,ProductDescription, ProductPrice, ProductColor, ProductImagePath) VALUES (:productname, :productdescription, :productprice, :productcolor, :productimagepath)";

        // $name = $this->product->getProductName();
        // $description = $this->product->getProductDescription();
        // $price = $this->product->getProductPrice();
        // $color = $this->product->getProductColor();
        // $image = $this->product->getProductImagePath();

        // $statement = $this->connection->prepare($sql);
        // $statement->bind_param(":productname", $name);
        // $statement->bind_param(":productdescription", $description);
        // $statement->bind_param(":productprice", $price);
        // $statement->bind_param(":productcolor", $color);
        // $statement->bind_param(":productimagepath", $image);

        // $statement->execute();
    }

    public function Update()
    {
        // duhet te ndryshohet query dhe atributet qe pranohen
        $stmt = $this->connection->prepare("INSERT INTO product (ProductName,ProductDescription, ProductPrice, ProductColor, ProductImagePath) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdss", $name, $description, $price, $color, $image);

        $name = $this->product->getProductName();
        $description = $this->product->getProductDescription();
        $price = $this->product->getProductPrice();
        $color = $this->product->getProductColor();
        $image = $this->product->getProductImagePath();
        $stmt->execute();

    }
}
