<?php
include_once 'DbConn.php';
include_once 'contactModel.php';
class contactMapper
{
    private $connection;
    /**
     * @var ContactModel
     */
    private $contactModel;

    public function __construct(\ContactModel $contactModel)
    {
        $obj = new DbConn();
        $this->connection = $obj->connectDB();
        $this->contactModel = $contactModel;
    }

    public function Insert()
    {
        $sql = "INSERT INTO Contact (name,email,phone,message) VALUES (:name,:email,:phone,:message)";

        $name = $this->contactModel->getName();
        $email = $this->contactModel->getEmail();
        $phone = $this->contactModel->getPhone();
        $message = $this->contactModel->getMessage();

        $statement = $this->connection->prepare($sql);
        $statement->bind_param(":name", $name);
        $statement->bind_param(":email", $email);
        $statement->bind_param(":phone", $phone);
        $statement->bind_param(":message", $message);

        $statement->execute();
    }
}
