<?php
    class Product{
        protected $productID;
        protected $productName;
        protected $productDescription;
        protected $productPrice;
        protected $productColor;
        protected $productImagePath;

        function __construct($productName,$productDescription,$productPrice, $productColor, $productImagePath){
            $this->productname=$productName;
            $this->productDescription=$productDescription;
            $this->productPrice=$productPrice;
            $this->productColor=$productColor;
            $this->productImagePath=$productImagePath;
            $this->productID=$this->generateID();
        }

        private function generateID(){
            return uniqid();
        }

        public function getProductName(){
            return $this->productName;
        }

        public function setProductName($productName){
            $this->productName=$productName;
        }

        public function getProductDescription(){
            return $this->productDescription;
        }

        public function setProductDescription($ProductDescription){
            $this->productDescription=$ProductDescription;
        }
        public function getProductPrice(){
            return $this->productPrice;
        }

        public function setProductPrice($ProductPrice){
            $this->productPrice = $ProductPrice;
        }
        public function getProductColor(){
            return $this->productColor;
        }

        public function setProductColor($productColor){
            $this->productColor=$productColor;
        }
        public function getProductImagePath(){
            return $this->productImagePath;
        }

        public function setProductImagePath($productImagePath){
            $this->productImagePath=$productImagePath;
        }

        public function registerProduct(){
            //some code;
        }

        public function __toString(){
            return $this->emri;
        } 

    }

?>