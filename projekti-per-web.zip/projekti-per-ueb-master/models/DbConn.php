<?php

    class DbConn {
    private $servername;
    private $user;
    private $password;
    private $databaseName;

    public function connectDB(){
        $this->servername="localhost";
        $this->user="root";
        $this->password="";
        $this->databaseName="ababear_db";

        $mysqli = new mysqli($this->servername, $this->user, $this->password, $this->databaseName);

        if ($mysqli -> connect_error) {
            die("The connection failed: " . $mysqli-> connect_error);
          } else{
            //successful conection
            return $mysqli;
          }
    }

}
// Check connection

?>
