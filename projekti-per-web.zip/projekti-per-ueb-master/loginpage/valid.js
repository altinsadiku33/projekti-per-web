var signup_link = document.querySelector('.a1');
var login_link = document.querySelector('.a2');

var signup_form = document.querySelector('.signup-form');
var login_form = document.querySelector('.login-form');

login_link.addEventListener('click', signup_hide);
signup_link.addEventListener('click', login_hide);

function signup_hide(){
	signup_form.style.display = "none";
	login_form.style.display = "block";
	signup_link.style.background = "rgb(173, 28, 28)";
	login_link.style.background = "rgb(95, 4, 4)";
}
function login_hide(){
	signup_form.style.display = "block";
	login_form.style.display = "none";
	signup_link.style.background = "rgb(95, 4, 4)";
	login_link.style.background = "rgb(173, 28, 28)";
}





var firstname = document.forms['signupForm']['firstname'];
var lastname = document.forms['signupForm']['lastname'];
var email = document.forms['signupForm']['email'];
var password = document.forms['signupForm']['password'];

var signup_error = document.querySelector('.signup_error');

firstname.addEventListener('textInput', fstnameVerify);
lastname.addEventListener('textInput', lstnameVerify);
email.addEventListener('textInput', emailVerify);
password.addEventListener('textInput', passwordVerify);

function signupValid(){
	if (firstname.value.length <= 2) {
		signup_error.style.display = "block";
		firstname.style.border = "1px solid white";
		signup_error.innerText = "Please Fill up Your Firstname";
		firstname.focus();
		return false;
	}
	if (lastname.value.length <= 2) {
		signup_error.style.display = "block";
		lastname.style.border = "1px solid white";
		signup_error.innerText = "Please Fill up Your Lastname";
		lastname.focus();
		return false;
	}
	if (email.value.length <= 8) {
		signup_error.style.display = "block";
		email.style.border = "1px solid white";
		signup_error.innerText = "Please Fill up Your Email or Phone";
		email.focus();
		return false;
	}
	if (password.value.length <= 3) {
		signup_error.style.display = "block";
		password.style.border = "1px solid white";
		signup_error.innerText = "Please Fill up Your Password";
		password.focus();
		return false;
	}
}
function fstnameVerify(){
	if (firstname.value.length > 1) {
		signup_error.style.display = "none";
		firstname.style.border = "1px solid rgb(173, 28, 28)";
		signup_error.innerText = "";
		return true;
	}
}
function lstnameVerify(){
	if (lastname.value.length > 1) {
		signup_error.style.display = "none";
		lastname.style.border = "1px solid rgb(173, 28, 28)";
		signup_error.innerText = "";
		return true;
	}
}
function emailVerify(){
	if (email.value.length > 7) {
		signup_error.style.display = "none";
		email.style.border = "1px solid rgb(173, 28, 28)";
		signup_error.innerText = "";
		return true;
	}
}
function passwordVerify(){
	if (password.value.length > 2) {
		signup_error.style.display = "none";
		password.style.border = "1px solid rgb(173, 28, 28)";
		signup_error.innerText = "";
		return true;
	}
}

var emailo = document.forms['loginForm']['emailo'];
var pass = document.forms['loginForm']['pass'];

var login_error = document.querySelector('.login_error');

emailo.addEventListener('textInput', eVerify);
pass.addEventListener('textInput', pVerify);

function loginValid(){
	if (emailo.value.length <= 2) {
		login_error.style.display = "block";
		emailo.style.border = "1px solid white";
		login_error.innerText = "Please Fill up Your Email or Phone";
		emailo.focus();
		return false;
	}
	if (pass.value.length <= 2) {
		login_error.style.display = "block";
		pass.style.border = "1px solid white";
		login_error.innerText = "Please Fill up Password";
		pass.focus();
		return false;
	}
}	

function eVerify(){
	if (emailo.value.length > 1) {
		login_error.style.display = "none";
		emailo.style.border = "1px solid rgb(173, 28, 28)";
		login_error.innerText = "";
		return true;
	}
}
function pVerify(){
	if (pass.value.length > 1) {
		login_error.style.display = "none";
		lastnpassame.style.border = "1px solid rgb(173, 28, 28)";
		login_error.innerText = "";
		return true;
	}
}