<?php
include_once __DIR__ . '\..\models\productMapper.php';
include_once __DIR__ . '\..\models\productModel.php';
include_once __DIR__ . '\..\models\DbConn.php';

class ProductControler
{
    public function InsertProduct($productName, $productDescription, $productPrice, $productColor, $productImagePath)
    {
        //insert produktin ndatabase
        $product = new Product($productName, $productDescription, $productPrice, $productColor, $productImagePath);
        $productMapper = new ProductMapper($product);
        $productMapper->Insert($productName, $productDescription, $productPrice, $productColor, $productImagePath);
    }

    public function GetProducts()
    {
        $testlidhja = new DbConn;
        $mysqli = $testlidhja->connectDB();

        $sql = "SELECT ID,ProductName, ProductDescription, ProductPrice, ProductColor, ProductImagePath FROM product";
        $result = $mysqli->query($sql);

        return $result;
    }
}
