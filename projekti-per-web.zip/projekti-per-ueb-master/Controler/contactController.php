<?php

include_once '../models/contactMapper.php';
include_once '../models/contactModel.php';
class contactController
{
    public function InsertContact($name, $email, $phone, $message)
    {
        $contacti = new contactModel($name, $email, $phone, $message);
        $studentMapper = new contactMapper($contacti);
        $studentMapper->Insert();

        return true;
    }
}