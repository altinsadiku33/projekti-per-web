<?php
include 'header.php';
?>
<div class="faqpage">
  <div class="faq-section">
    <div class="faqs">
      <h1>Frequently Asked Questions</h1>
      <b>
        <p>FAQ 1#</p>
      </b>
      <p>lorem ipsum lorem ipsum lorem ipsum lorem ipsumlorem ipsum lorem ipsumlorem ipsum lorem ipsum</p>
      <b>
        <p>FAQ 2#</p>
      </b>
      <p>lorem ipsum lorem ipsum lorem ipsum lorem ipsumlorem ipsum lorem ipsumlorem ipsum lorem ipsum </p>
      <b>
        <p>FAQ 3#</p>
      </b>
      <p>lorem ipsum lorem ipsum lorem ipsum lorem ipsumlorem ipsum lorem ipsumlorem ipsum lorem ipsum</p>
      <b>
        <p>FAQ 4#</p>
      </b>
      <p>lorem ipsum lorem ipsum lorem ipsum lorem ipsumlorem ipsum lorem ipsumlorem ipsum lorem ipsum</p>
      <b>
        <p>FAQ 5#</p>
      </b>
      <p>lorem ipsum lorem ipsum lorem ipsum lorem ipsumlorem ipsum lorem ipsumlorem ipsum lorem ipsum</p>
      <b>
        <p>FAQ 6#</p>
      </b>
      <p>lorem ipsum lorem ipsum lorem ipsum lorem ipsumlorem ipsum lorem ipsumlorem ipsum lorem ipsum</p>
      <b>
        <p>FAQ 7#</p>
      </b>
      <p>lorem ipsum lorem ipsum lorem ipsum lorem ipsumlorem ipsum lorem ipsumlorem ipsum lorem ipsum</p>
    </div>
  </div>
</div>
<?php
include 'footer.php'
?>