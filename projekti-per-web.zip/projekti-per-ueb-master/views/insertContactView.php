<?php
include_once '../controller/contactController.php';
if (isset($_POST['submitbtn'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];
    $view = new insertContactView();
    $view->insertContact($name, $email, $phone, $message);
}

class insertContactView
{
    public function insertContact($name, $email, $phone, $message)
    {
        // dergojme kerkesen ne controller
        $controller = new contactController();
        $response = $controller->InsertContact($name, $email, $phone, $message);

        if ($response) {
?>
            <h1>U regjistrua me sukses</h1>
        <?php

        } else {
        ?>
            <h1>Nuk u regjistrua me sukses</h1>
<?php
        }
    }
}
