<?php
include 'header.php';
?>

<h1 class="page-title">Admin Panel</h1>

<div class="dashboard">
    <h1>-Shto Produktet e reja</h1>
    <form action="insertProductView.php" method="post" class="panel-form">
        <input type="text" name="name" placeholder="Shkruaj emrin" />
        <input type="text" name="description" placeholder="Shkruaj dscp" />
        <input type="number" step="0.01" name="price" placeholder="Shrkuaj cmimin">
        <input type="text" name="color" placeholder="Shkruaj color" />
        <input type="text" name="imagepath" placeholder="Shkruaj image path" />

        <input type="submit" name="submitbtn" value="Register" class="dashboardsubmitbtn"/>
    </form>
</div>



<?php
include 'footer.php';
?>