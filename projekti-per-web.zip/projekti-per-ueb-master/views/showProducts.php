<?php
include_once '../Controler/productControler.php';
class StudentView
{
    public function FillTableRowsWithProducts()
    {
        // dergojme kerkesen ne controller
        $controller = new ProductControler();
        $data = $controller->GetProducts();

        return $data;
    }
}
