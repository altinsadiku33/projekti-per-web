
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home Page</title>
  <link rel="stylesheet" href="views/style.css">
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <div class="discount-line">
    <div class="gray-cont">
      <div class="gray-part">
        <p>VALENTINE’S DAY FOR YOUR PARTNER</p>
      </div>
      <div class="red-part">
        <p> <span>GET 50% OFF</span> FOR EACH PRODUCT AND FREE SHIPPING</p>
      </div>
    </div>
  </div>

  <header>
    <div class="menu">
      <a href="index.html" class="menulogo">
        <h1>ABA BEAR</h1>
      </a>
      <ul class="menupages">
        <li class="pagelink"> <a class="nav-link" href="index.php">Home</a> </li>
        <li class="pagelink"> <a class="nav-link" href="aboutpage/aboutpage.html">About</a> </li>
        <li class="pagelink"> <a class="nav-link" href="contactpage/contactpage.html">Contant</a> </li>
        <li class="pagelink"> <a class="nav-link" href="ourproducts.php">Our Products</a> </li>
        <li class="pagelink"> <a class="nav-link" href="views/faqpage.php">FAQs</a> </li>
      </ul>
      <ul class="navlinks">
        <li class="navlink">
          <a href="login.php"><img src="images/login-icon.png" class="navbar-icons" alt=""></a>
        </li>
      </ul>
    </div>
  </header>