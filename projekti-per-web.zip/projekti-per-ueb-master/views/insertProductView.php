<?php
include_once '../Controler/productControler.php';
if (isset($_POST['submitbtn'])) {
    $productName = $_POST['name'];
    $productDescription = $_POST['description'];
    $productPrice = $_POST['price'];
    $productColor = $_POST['color'];
    $productImagePath = $_POST['imagepath'];
    $view = new InsertView();
    $view->insertProduct($productName, $productDescription, $productPrice, $productColor, $productImagePath);
}

class InsertView
{
    public function insertProduct($productName, $productDescription, $productPrice, $productColor, $productImagePath)
    {
        // dergojme kerkesen ne controller
        $controller = new ProductControler();
        $response = $controller->InsertProduct($productName, $productDescription, $productPrice, $productColor, $productImagePath);

        if ($response) {
?>
            <h1>U regjistrua me sukses</h1>
        <?php

        } else {
        ?>
            <h1>Nuk u regjistrua me sukses</h1>
<?php
        }
    }
}