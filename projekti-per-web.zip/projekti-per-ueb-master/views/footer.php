<footer>
    <div class="footercol1">
      <p>Your satisfaction is always our first priority!</p>
      <p>All rights reserved 2020</p>
    </div>
    <div class="footercol2">
      <p>Follow us</p>
      <div>
        <a href="https://instagram.com">
          <img src="images/instagram.png" alt="">
        </a>
        <a href="https://twitter.com">
          <img src="images/twitter.png" alt="">
        </a>
        <a href="https://facebook.com">
          <img src="images/facebook.png" alt="">
        </a>
      </div>
    </div>
    <div class="footercol3">
      <p>We accept payments in:</p>
      <img src="images/paymentoptions.png" alt="">
    </div>
  </footer>

  <script src="main.js"></script>
</body>

</html>