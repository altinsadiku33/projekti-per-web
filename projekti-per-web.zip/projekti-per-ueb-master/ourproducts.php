<?php
include_once('models/DbConn.php');
include_once('Controler/productControler.php');

include('views/header.php');
?>


<div class="produktet">
    <div class="title0">
      <h1>Quality is our first Priority</h1>
      <p><i>All of our products are handmade in Kosovo.</i></p>
    </div>
    <div class="cards">
      <?php

      $productC = new ProductControler();
      $result = $productC->GetProducts();

      if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
      ?>
          <div class="card">
            <img src="images/bear.jpeg" alt="" style="width:100%">
            <h1 style="font-size: 20px;"><?= $row['ProductName'] ?></h1>
            <p class="price"><i>$<?= $row["ProductPrice"] ?>.99</i></p>
            <button>Buy now</button>
          </div>

      <?php
        }
      } else {
        echo "0 results";
      }
      ?>
    </div>
  </div>

  <?php
  include('views/footer.php');
  ?>