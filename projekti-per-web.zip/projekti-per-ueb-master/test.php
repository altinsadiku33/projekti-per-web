<?php
include 'models\DbConn.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="views/insertProductView.php" method="post">
        <input type="text" name="productName" placeholder="Shkruaj emrin" />
        <input type="text" name="productDescription" placeholder="Shkruaj description" />
        <input type="text" name="productPrice" placeholder="Shkruaj price" />
        <input type="text" name="productColor" placeholder="Shkruaj color" />
        <input type="text" name="productImagePath" placeholder="Shkruaj image" />
        <input type="submit" name="submitbtn" value="Register" />
    </form>



<?php

    $testlidhja = new DbConn();
    $mysqli = $testlidhja-> connectDB();

$sql = "SELECT ID,ProductName, ProductDescription, ProductPrice, ProductColor, ProductImagePath FROM product";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br> id: ". $row["ID"]. " - Name: ". $row["ProductName"]. " " . $row["ProductPrice"] . "<br>";
    }
} else {
    echo "0 results";
}


?>
</body>
</html>